create schema PolicyEndorsement;

create table PolicyEndorsement.InsuranceProducts
(
   Product_ID integer Constraint ProId_pk primary key not null,
   Product_name varchar(50) not null,
   Product_description varchar(50)
);

   
create table PolicyEndorsement.Customer
(
    customer_id integer Constraint CustId_pk primary key not null,
	product_id integer constraint ProId_fk foreign key references PolicyEndorsement.InsuranceProducts(Product_ID),
	Customer_name varchar(50) not null,
	Customer_address varchar(100) not null,
	Mobile_number varchar(10) not null,
	gender varchar(1) check(gender='F' or gender='M'),
	Smoker varchar(5),
	Date_of_Birth date,
	Hobbies varchar(50)
); 


create table PolicyEndorsement.Policy
(
   Policy_number integer constraint Policy_pk primary key,
   Customer_id integer constraint CustID_fk foreign key references PolicyEndorsement.Customer(Customer_id),
   product_id integer 
);

   
 create table PolicyEndorsement.LoginDetails
 (
    customer_id integer,
	Customer_Password varchar(10)
 );
